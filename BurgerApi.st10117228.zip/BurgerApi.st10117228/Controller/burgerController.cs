using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace BurgerApi.controllers
{

    [ApiController]
    [Route("[Controller]")]

    public class BurgerController : ControllerBase
    {
        [HttpGet]
        

        public List<Burger> Get(String burgerType = "plain")
        {
            Extras extras = new Extras();
            BurgerFactory burgerFactory = new BurgerFactory();
            IBurger burger = burgerFactory.getBurger(burgerType);
            List<Burger> returnedBurger = new List<Burger>();
            returnedBurger.Add(new Burger{patty =burger.getPatty()
            ,bun= burger.getBun()/*,extra = burger.getExtra()*/});
           
            return returnedBurger;
        }
    }
}