using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

public class GourmetBurger : IBurger
{
 public string getBun()
{
    return "ciabatta";
}

public string getPatty()
{
    return "veal";
}

/*public string getExtra()
{
    return "caramelised onion";
}*/


}