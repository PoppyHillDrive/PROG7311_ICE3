using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

//namespace//
namespace BurgerApi
{

    public class BurgerFactory
    {

        //instace of iburger because thats the min that needs to return
        public IBurger returnInstance;

        public IBurger getBurger(String burgerType)
        {
            //switvh case,, each case is a type of burger
            switch (burgerType)
            {
                case ("plain"):
                    returnInstance = new PlainBurger();

                    break;

                case ("cheese"):
                    returnInstance = new CheeseBurger();

                    break;

                case ("chicken"):
                    returnInstance = new ChickenBurger();

                    break;

                case ("fish"):
                    returnInstance = new FishBurger();

                    break;

                case ("gourmet"):
                    returnInstance = new GourmetBurger();

                    break;

                case ("veggie"):
                    returnInstance = new VeggieBurger();

                    break;
            }


            return returnInstance;

        }
    }


}